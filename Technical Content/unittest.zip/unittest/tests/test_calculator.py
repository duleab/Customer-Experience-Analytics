"""
Unit tests for Calculator class - TDD Demo

These tests demonstrate Test-Driven Development:
1. Tests are written first
2. Tests FAIL initially (no validation in calculator)
3. Uncomment validation code in calculator.py
4. Tests PASS

Run with: python3 -m unittest tests.test_calculator -v
"""

import unittest
import sys
import os

# Add the src directory to the path so we can import our Calculator
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from calculator import Calculator


class TestCalculator(unittest.TestCase):
    """Test cases for Calculator class."""
    
    def setUp(self):
        """Set up test fixtures before each test method."""
        self.calc = Calculator()
    
    # ========== BASIC OPERATIONS (ALWAYS PASS) ==========
    
    def test_add_positive_numbers(self):
        """Test adding two positive numbers."""
        result = self.calc.add(3, 5)
        self.assertEqual(result, 8)
    
    def test_add_negative_numbers(self):
        """Test adding two negative numbers."""
        result = self.calc.add(-3, -5)
        self.assertEqual(result, -8)
    
    def test_subtract_positive_numbers(self):
        """Test subtracting positive numbers."""
        result = self.calc.subtract(10, 3)
        self.assertEqual(result, 7)
    
    def test_multiply_positive_numbers(self):
        """Test multiplying positive numbers."""
        result = self.calc.multiply(4, 5)
        self.assertEqual(result, 20)
    
    def test_multiply_by_zero(self):
        """Test multiplying by zero."""
        result = self.calc.multiply(5, 0)
        self.assertEqual(result, 0)
    
    # ========== TDD TESTS (FAIL FIRST, THEN PASS) ==========
    
    def test_divide_positive_numbers(self):
        """Test dividing positive numbers."""
        result = self.calc.divide(10, 2)
        self.assertEqual(result, 5.0)
    
    def test_divide_by_zero_raises_value_error(self):
        """
        TDD Test: Division by zero should raise ValueError.
        
        WILL FAIL initially because:
        - Test expects: ValueError("Cannot divide by zero")
        - Code raises: ZeroDivisionError
        
        To fix: Uncomment validation in Calculator.divide()
        """
        with self.assertRaises(ValueError) as context:
            self.calc.divide(10, 0)
        self.assertEqual(str(context.exception), "Cannot divide by zero")
    
    def test_square_root_positive_number(self):
        """Test square root of positive number."""
        result = self.calc.square_root(9)
        self.assertEqual(result, 3.0)
    
    def test_square_root_zero(self):
        """Test square root of zero."""
        result = self.calc.square_root(0)
        self.assertEqual(result, 0.0)
    
    def test_square_root_negative_raises_value_error(self):
        """
        TDD Test: Square root of negative should raise ValueError.
        
        WILL FAIL initially because:
        - Test expects: ValueError("Cannot calculate square root of negative number")
        - Code raises: ValueError("math domain error")
        
        To fix: Uncomment validation in Calculator.square_root()
        """
        with self.assertRaises(ValueError) as context:
            self.calc.square_root(-4)
        self.assertEqual(str(context.exception), "Cannot calculate square root of negative number")


if __name__ == '__main__':
    print("TDD Demo: Running Calculator Tests")
    print("=" * 40)
    print("If tests fail, uncomment validation code in src/calculator.py")
    print("=" * 40)
    unittest.main(verbosity=2) 