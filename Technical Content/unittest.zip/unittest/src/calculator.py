"""
Simple Calculator class for TDD (Test-Driven Development) demo.
Perfect for junior developers learning unit testing.

TDD Process:
1. Run tests - they will FAIL (validation not implemented)
2. Uncomment validation code to make tests pass
3. Run tests again - they will PASS
"""

import math


class Calculator:
    """A simple calculator for demonstrating TDD."""
    
    def add(self, a, b):
        """Add two numbers."""
        return a + b
    
    def subtract(self, a, b):
        """Subtract second number from first."""
        return a - b
    
    def multiply(self, a, b):
        """Multiply two numbers."""
        return a * b
    
    def divide(self, a, b):
        """
        Divide first number by second.
        
        TDD Demo: Tests expect ValueError for division by zero,
        but code currently raises ZeroDivisionError.
        """
        # TODO: Uncomment to make tests pass
        if b == 0:
            raise ValueError("Cannot divide by zero")
        
        return a / b
    
    def square_root(self, number):
        """
        Calculate square root of a number.
        
        TDD Demo: Tests expect ValueError for negative numbers,
        but code currently raises different error.
        """
        # TODO: Uncomment to make tests pass
        if number < 0:
            raise ValueError("Cannot calculate square root of negative number")
        
        return math.sqrt(number) 