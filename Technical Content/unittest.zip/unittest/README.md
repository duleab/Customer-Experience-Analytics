# 🧮 Simple Calculator TDD Demo

**Perfect for junior developers learning Test-Driven Development!**

This demo shows the core concept of TDD: Write tests first, see them fail, then make them pass.

## 🎯 What You'll Learn

- **Test-Driven Development (TDD)**: Write tests first, then implement features
- **How tests guide implementation**: Failing tests tell you exactly what to build
- **Unit testing basics**: Assertions, test structure, and running tests

## 🚀 Quick Start

```bash
# Navigate to the demo folder
cd simple_demo

# Step 1: Run tests (they will FAIL)
python3 -m unittest tests.test_calculator -v

# Step 2: Open src/calculator.py and uncomment the validation code
# Step 3: Run tests again (they will PASS)
python3 -m unittest tests.test_calculator -v
```

## 📁 Project Structure

```
simple_demo/
├── README.md                    # This file
├── src/
│   ├── __init__.py
│   └── calculator.py            # Calculator with validation commented out
└── tests/
    ├── __init__.py
    └── test_calculator.py       # Tests expecting validation
```

## 🔄 TDD Process

### Step 1: See Tests Fail (Red)
```bash
python3 -m unittest tests.test_calculator -v
```
- 2 tests will fail: `test_divide_by_zero_raises_value_error` and `test_square_root_negative_raises_value_error`
- Tests expect specific `ValueError` messages
- Code currently raises different errors

### Step 2: Make Tests Pass (Green)
1. Open `src/calculator.py`
2. Find the commented validation code (lines starting with `#`)
3. Uncomment these lines by removing the `#`
4. Save the file

### Step 3: Verify Tests Pass
```bash
python3 -m unittest tests.test_calculator -v
```
All tests should now pass! 🎉

## 🧮 The Calculator

Simple calculator with 5 methods:
- `add(a, b)` - Always works
- `subtract(a, b)` - Always works  
- `multiply(a, b)` - Always works
- `divide(a, b)` - **TDD demo**: Needs validation for division by zero
- `square_root(number)` - **TDD demo**: Needs validation for negative numbers

## 📝 Example TDD Cycle

**Before (test fails):**
```python
def divide(self, a, b):
    # if b == 0:
    #     raise ValueError("Cannot divide by zero")
    return a / b  # Raises ZeroDivisionError
```

**After (test passes):**
```python
def divide(self, a, b):
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b  # Now raises ValueError as expected
```

## 🎓 Key Takeaways

- **Tests drive implementation**: Failing tests show exactly what to build
- **Red → Green cycle**: See failure, then make it pass
- **Specific error messages**: Tests can verify exact error text
- **Confidence in changes**: Tests catch regressions when you modify code

## 💡 Try This

1. **Run the TDD cycle** - See tests fail, then pass
2. **Add a new method** like `power(base, exponent)`
3. **Write tests first** for your new method
4. **Implement the method** to make tests pass
5. **Break something** - Change code and see which tests catch it

---